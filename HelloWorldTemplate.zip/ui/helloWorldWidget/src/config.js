export default {
  supportedCultures: [ 'en-GB', 'th-TH' ],
  supportedSites: [ 'th', 'sg', 'hk' ]
};
