// Where is this file used?
import React from 'react';
import { context } from 'travix-fireball-ui';

const Component = React.createClass(require('./component')(React));
React.render(<Component _context={context} appName='{APP_NAME}' />, document.getElementById('app'));
