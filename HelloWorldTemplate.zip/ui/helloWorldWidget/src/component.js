import Travix from 'travix-fireball-ui';

export default function (React) {
  // TODO REMOVE THIS LATER
  document.body.classList.add('fireball');

  return Travix.createWidget({
    render: function () {
      return (
        <p>Hello world from {APP_NAME}!</p>
      );
    }
  });
}