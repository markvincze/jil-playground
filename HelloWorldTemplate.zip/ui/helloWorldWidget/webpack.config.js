module.exports = {
  devtool: 'eval-source-map',
  entry: [
    './src/index.js'
  ],
  module: {
    loaders: [
      {
        test:  /\.(js|jsx)$/,
        exclude: /node_modules/,
        loader: 'babel'
      },
      {
        test: /\.css/,
        loader: 'style-loader!css-loader'
      },
    ]
  },
  resolve: {
    extensions: ['', '.js', '.jsx']
  },
  output: {
    path: __dirname + '/demo',
    publicPath: '/',
    filename: 'index.js'
  },
  devServer: {
    contentBase: './demo'
  }
};
